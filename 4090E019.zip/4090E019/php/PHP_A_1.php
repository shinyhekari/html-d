<HTML>
<HEAD>
</HEAD>
<BODY>
<h2>我的第一個 PHP 程式</h2>
<?php
echo "山中相送罷，日暮掩柴扉。";
echo "春草明年綠，王孫歸不歸？";
?>
</BODY>
</HTML>
